// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSYSTOLIC_TILE_PROCESSOR_H
#define XSYSTOLIC_TILE_PROCESSOR_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsystolic_tile_processor_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XSystolic_tile_processor_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XSystolic_tile_processor;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSystolic_tile_processor_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSystolic_tile_processor_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSystolic_tile_processor_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSystolic_tile_processor_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XSystolic_tile_processor_Initialize(XSystolic_tile_processor *InstancePtr, UINTPTR BaseAddress);
XSystolic_tile_processor_Config* XSystolic_tile_processor_LookupConfig(UINTPTR BaseAddress);
#else
int XSystolic_tile_processor_Initialize(XSystolic_tile_processor *InstancePtr, u16 DeviceId);
XSystolic_tile_processor_Config* XSystolic_tile_processor_LookupConfig(u16 DeviceId);
#endif
int XSystolic_tile_processor_CfgInitialize(XSystolic_tile_processor *InstancePtr, XSystolic_tile_processor_Config *ConfigPtr);
#else
int XSystolic_tile_processor_Initialize(XSystolic_tile_processor *InstancePtr, const char* InstanceName);
int XSystolic_tile_processor_Release(XSystolic_tile_processor *InstancePtr);
#endif

void XSystolic_tile_processor_Start(XSystolic_tile_processor *InstancePtr);
u32 XSystolic_tile_processor_IsDone(XSystolic_tile_processor *InstancePtr);
u32 XSystolic_tile_processor_IsIdle(XSystolic_tile_processor *InstancePtr);
u32 XSystolic_tile_processor_IsReady(XSystolic_tile_processor *InstancePtr);
void XSystolic_tile_processor_EnableAutoRestart(XSystolic_tile_processor *InstancePtr);
void XSystolic_tile_processor_DisableAutoRestart(XSystolic_tile_processor *InstancePtr);

void XSystolic_tile_processor_Set_M(XSystolic_tile_processor *InstancePtr, u32 Data);
u32 XSystolic_tile_processor_Get_M(XSystolic_tile_processor *InstancePtr);
void XSystolic_tile_processor_Set_N(XSystolic_tile_processor *InstancePtr, u32 Data);
u32 XSystolic_tile_processor_Get_N(XSystolic_tile_processor *InstancePtr);
void XSystolic_tile_processor_Set_K(XSystolic_tile_processor *InstancePtr, u32 Data);
u32 XSystolic_tile_processor_Get_K(XSystolic_tile_processor *InstancePtr);
void XSystolic_tile_processor_Set_mem_A(XSystolic_tile_processor *InstancePtr, u64 Data);
u64 XSystolic_tile_processor_Get_mem_A(XSystolic_tile_processor *InstancePtr);
void XSystolic_tile_processor_Set_mem_B(XSystolic_tile_processor *InstancePtr, u64 Data);
u64 XSystolic_tile_processor_Get_mem_B(XSystolic_tile_processor *InstancePtr);
void XSystolic_tile_processor_Set_mem_C(XSystolic_tile_processor *InstancePtr, u64 Data);
u64 XSystolic_tile_processor_Get_mem_C(XSystolic_tile_processor *InstancePtr);

void XSystolic_tile_processor_InterruptGlobalEnable(XSystolic_tile_processor *InstancePtr);
void XSystolic_tile_processor_InterruptGlobalDisable(XSystolic_tile_processor *InstancePtr);
void XSystolic_tile_processor_InterruptEnable(XSystolic_tile_processor *InstancePtr, u32 Mask);
void XSystolic_tile_processor_InterruptDisable(XSystolic_tile_processor *InstancePtr, u32 Mask);
void XSystolic_tile_processor_InterruptClear(XSystolic_tile_processor *InstancePtr, u32 Mask);
u32 XSystolic_tile_processor_InterruptGetEnabled(XSystolic_tile_processor *InstancePtr);
u32 XSystolic_tile_processor_InterruptGetStatus(XSystolic_tile_processor *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
