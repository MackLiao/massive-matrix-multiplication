// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xsystolic_tile_processor.h"

extern XSystolic_tile_processor_Config XSystolic_tile_processor_ConfigTable[];

#ifdef SDT
XSystolic_tile_processor_Config *XSystolic_tile_processor_LookupConfig(UINTPTR BaseAddress) {
	XSystolic_tile_processor_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XSystolic_tile_processor_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XSystolic_tile_processor_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XSystolic_tile_processor_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSystolic_tile_processor_Initialize(XSystolic_tile_processor *InstancePtr, UINTPTR BaseAddress) {
	XSystolic_tile_processor_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSystolic_tile_processor_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSystolic_tile_processor_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XSystolic_tile_processor_Config *XSystolic_tile_processor_LookupConfig(u16 DeviceId) {
	XSystolic_tile_processor_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSYSTOLIC_TILE_PROCESSOR_NUM_INSTANCES; Index++) {
		if (XSystolic_tile_processor_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSystolic_tile_processor_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSystolic_tile_processor_Initialize(XSystolic_tile_processor *InstancePtr, u16 DeviceId) {
	XSystolic_tile_processor_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSystolic_tile_processor_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSystolic_tile_processor_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

