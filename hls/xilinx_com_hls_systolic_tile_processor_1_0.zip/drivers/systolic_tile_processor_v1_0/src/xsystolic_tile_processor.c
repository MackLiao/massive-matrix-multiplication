// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsystolic_tile_processor.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSystolic_tile_processor_CfgInitialize(XSystolic_tile_processor *InstancePtr, XSystolic_tile_processor_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSystolic_tile_processor_Start(XSystolic_tile_processor *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSystolic_tile_processor_IsDone(XSystolic_tile_processor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSystolic_tile_processor_IsIdle(XSystolic_tile_processor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSystolic_tile_processor_IsReady(XSystolic_tile_processor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSystolic_tile_processor_EnableAutoRestart(XSystolic_tile_processor *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSystolic_tile_processor_DisableAutoRestart(XSystolic_tile_processor *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_AP_CTRL, 0);
}

void XSystolic_tile_processor_Set_M(XSystolic_tile_processor *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_M_DATA, Data);
}

u32 XSystolic_tile_processor_Get_M(XSystolic_tile_processor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_M_DATA);
    return Data;
}

void XSystolic_tile_processor_Set_N(XSystolic_tile_processor *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_N_DATA, Data);
}

u32 XSystolic_tile_processor_Get_N(XSystolic_tile_processor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_N_DATA);
    return Data;
}

void XSystolic_tile_processor_Set_K(XSystolic_tile_processor *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_K_DATA, Data);
}

u32 XSystolic_tile_processor_Get_K(XSystolic_tile_processor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_K_DATA);
    return Data;
}

void XSystolic_tile_processor_Set_mem_A(XSystolic_tile_processor *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_A_DATA, (u32)(Data));
    XSystolic_tile_processor_WriteReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_A_DATA + 4, (u32)(Data >> 32));
}

u64 XSystolic_tile_processor_Get_mem_A(XSystolic_tile_processor *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_A_DATA);
    Data += (u64)XSystolic_tile_processor_ReadReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_A_DATA + 4) << 32;
    return Data;
}

void XSystolic_tile_processor_Set_mem_B(XSystolic_tile_processor *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_B_DATA, (u32)(Data));
    XSystolic_tile_processor_WriteReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_B_DATA + 4, (u32)(Data >> 32));
}

u64 XSystolic_tile_processor_Get_mem_B(XSystolic_tile_processor *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_B_DATA);
    Data += (u64)XSystolic_tile_processor_ReadReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_B_DATA + 4) << 32;
    return Data;
}

void XSystolic_tile_processor_Set_mem_C(XSystolic_tile_processor *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_C_DATA, (u32)(Data));
    XSystolic_tile_processor_WriteReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_C_DATA + 4, (u32)(Data >> 32));
}

u64 XSystolic_tile_processor_Get_mem_C(XSystolic_tile_processor *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_tile_processor_ReadReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_C_DATA);
    Data += (u64)XSystolic_tile_processor_ReadReg(InstancePtr->Control_r_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_R_ADDR_MEM_C_DATA + 4) << 32;
    return Data;
}

void XSystolic_tile_processor_InterruptGlobalEnable(XSystolic_tile_processor *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_GIE, 1);
}

void XSystolic_tile_processor_InterruptGlobalDisable(XSystolic_tile_processor *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_GIE, 0);
}

void XSystolic_tile_processor_InterruptEnable(XSystolic_tile_processor *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_IER);
    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_IER, Register | Mask);
}

void XSystolic_tile_processor_InterruptDisable(XSystolic_tile_processor *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_IER);
    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSystolic_tile_processor_InterruptClear(XSystolic_tile_processor *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_tile_processor_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_ISR, Mask);
}

u32 XSystolic_tile_processor_InterruptGetEnabled(XSystolic_tile_processor *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_IER);
}

u32 XSystolic_tile_processor_InterruptGetStatus(XSystolic_tile_processor *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSystolic_tile_processor_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_TILE_PROCESSOR_CONTROL_ADDR_ISR);
}

